public class Colas_Sin_Librerias {

    public static void main(String[] args) {
        simple();
        Circular();
        Prioridad();
        doble();
    }

    // =====================================
    // 1. COLA SIMPLE
    // =====================================

    private static final String[] datosSimple = new String[5];
    private static int cantidadSimple = 0;

    static void simple() {

        System.out.println("\n1. COLA SIMPLE: FIFO");

        encolarSimple("Sara");
        encolarSimple("Maria");
        encolarSimple("Angelica");

        System.out.println("Elementos de la cola:");

        for (int i = 0; i < cantidadSimple; i++) {
            System.out.println(datosSimple[i]);
        }

        System.out.println("Sale: " + desencolarSimple());

        System.out.println("Quedan:");

        for (int i = 0; i < cantidadSimple; i++) {
            System.out.println(datosSimple[i]);
        }
    }

    static void encolarSimple(String nombre) {

        if (cantidadSimple == datosSimple.length)
            throw new IllegalStateException("Cola llena");

        datosSimple[cantidadSimple++] = nombre;
    }

    static String desencolarSimple() {

        if (cantidadSimple == 0) return null;

        String primero = datosSimple[0];

        for (int i = 0; i < cantidadSimple - 1; i++) {
            datosSimple[i] = datosSimple[i + 1];
        }

        datosSimple[--cantidadSimple] = null;

        return primero;
    }

    static void agregarInicioSimple(String nombre) {

        if (cantidadSimple == datosSimple.length)
            throw new IllegalStateException("Cola llena");

        for (int i = cantidadSimple; i > 0; i--) {
            datosSimple[i] = datosSimple[i - 1];
        }

        datosSimple[0] = nombre;
        cantidadSimple++;
    }

    static String retirarFinalSimple() {

        if (cantidadSimple == 0) return null;

        String ultimo = datosSimple[--cantidadSimple];

        datosSimple[cantidadSimple] = null;

        return ultimo;
    }

    // =====================================
    // 2. COLA CIRCULAR
    // =====================================

    private static final String[] datosCircular = new String[3];

    private static int frenteCircular = 0;
    private static int finCircular = 0;
    private static int cantidadCircular = 0;

    static void Circular() {

        System.out.println("\n2. COLA CIRCULAR");

        EncolarCircular("Carlos");
        EncolarCircular("Pedro");
        EncolarCircular("Juan");

        System.out.println("Sale: " + desencolarCircular());

        EncolarCircular("Luis");

        System.out.println("Elementos de la cola circular:");

        for (int i = 0; i < cantidadCircular; i++) {
            int posicion = (frenteCircular + i) % datosCircular.length;
            System.out.println(datosCircular[posicion]);
        }
    }

    static void EncolarCircular(String nombre) {

        if (cantidadCircular == datosCircular.length)
            throw new IllegalStateException("Cola circular llena");

        datosCircular[finCircular] = nombre;

        finCircular = (finCircular + 1) % datosCircular.length;

        cantidadCircular++;
    }

    static String desencolarCircular() {

        if (cantidadCircular == 0) return null;

        String primero = datosCircular[frenteCircular];

        datosCircular[frenteCircular] = null;

        frenteCircular = (frenteCircular + 1) % datosCircular.length;

        cantidadCircular--;

        return primero;
    }

    // =====================================
    // 3. COLA DE PRIORIDAD
    // =====================================

    private static final Integer[] datosprioridad = new Integer[5];

    private static int cantidadprioridad = 0;

    static void Prioridad() {

        System.out.println("\n3. COLA DE PRIORIDAD");

        Encolarprioridad(3);
        Encolarprioridad(1);
        Encolarprioridad(5);
        Encolarprioridad(2);

        System.out.println("Sale primero la prioridad mas alta:");

        while (cantidadprioridad > 0) {
            System.out.println(DesencolarPrioridad());
        }
    }

    static void Encolarprioridad(int prioridad) {

        if (cantidadprioridad == datosprioridad.length)
            throw new IllegalStateException("Cola llena");

        datosprioridad[cantidadprioridad++] = prioridad;
    }

    static Integer DesencolarPrioridad() {

        if (cantidadprioridad == 0) return null;

        int mejor = 0;

        for (int i = 1; i < cantidadprioridad; i++) {

            if (datosprioridad[i] < datosprioridad[mejor]) {
                mejor = i;
            }
        }

        Integer resultado = datosprioridad[mejor];

        for (int i = mejor; i < cantidadprioridad - 1; i++) {
            datosprioridad[i] = datosprioridad[i + 1];
        }

        datosprioridad[--cantidadprioridad] = null;

        return resultado;
    }

    // =====================================
    // 4. COLA DOBLE
    // =====================================

    private static final String[] datosDoble = new String[5];

    private static int frenteDoble = 0;
    private static int cantidadDoble = 0;

    static void doble() {

        System.out.println("\n4. COLA DOBLE (DEQUE)");

        agregarFinalDoble("Ana");
        agregarFinalDoble("Luis");
        agregarInicioDoble("Maria");

        System.out.println("Elementos de la cola doble:");

        mostrarDoble();

        System.out.println("Sale del inicio: " + retirarInicioDoble());

        System.out.println("Sale del final: " + retirarFinalDoble());

        System.out.println("Elementos restantes:");

        mostrarDoble();
    }

    static void agregarInicioDoble(String nombre) {

        if (cantidadDoble == datosDoble.length)
            throw new IllegalStateException("Cola doble llena");

        frenteDoble = (frenteDoble - 1 + datosDoble.length)
                % datosDoble.length;

        datosDoble[frenteDoble] = nombre;

        cantidadDoble++;
    }

    static void agregarFinalDoble(String nombre) {

        if (cantidadDoble == datosDoble.length)
            throw new IllegalStateException("Cola doble llena");

        int fin = (frenteDoble + cantidadDoble) % datosDoble.length;

        datosDoble[fin] = nombre;

        cantidadDoble++;
    }

    static String retirarInicioDoble() {

        if (cantidadDoble == 0) return null;

        String primero = datosDoble[frenteDoble];

        datosDoble[frenteDoble] = null;

        frenteDoble = (frenteDoble + 1) % datosDoble.length;

        cantidadDoble--;

        return primero;
    }

    static String retirarFinalDoble() {

        if (cantidadDoble == 0) return null;

        int fin = (frenteDoble + cantidadDoble - 1)
                % datosDoble.length;

        String ultimo = datosDoble[fin];

        datosDoble[fin] = null;

        cantidadDoble--;

        return ultimo;
    }

    static void mostrarDoble() {

        for (int i = 0; i < cantidadDoble; i++) {

            int posicion = (frenteDoble + i) % datosDoble.length;

            System.out.println(datosDoble[posicion]);
        }
    }
}